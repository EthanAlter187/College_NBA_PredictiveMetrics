import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import QuantileTransformer
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import seaborn as sns


# Load college dataset
data = pd.read_csv('nba_players_college_stats.csv')

# only include players who ended their college careers between 200 and 2010
data["season_start"] = data["season"].str[:4].astype(int)
player_ranges = data.groupby("player_html")["season_start"].agg(["min", "max"]).reset_index()

# 1999 because season goes from 1999-2000
# 2009 because season goes from 2009-2010
filtered_players = player_ranges[
    (player_ranges["max"] >= 1999) & 
    (player_ranges["min"] <= 2009) & 
    (player_ranges["max"] <= 2009)
]

# keep only rows whose player_html is in the filtered set
filtered_data = data[data["player_html"].isin(filtered_players["player_html"])].copy()

# drop rows with missing values in critical columns
filtered_data = filtered_data.dropna(subset=['trb', 'ast', 'pts', 'g', 'ft', 'fta', 'fg', 'fga', 
                                             'fg_pct', 'ft_pct', 'trb_per_g', 'ast_per_g', 'pts_per_g'])

# Fill missing values in less critical columns with zeros
cols_to_zero = ['mp', 'fg3', 'fg3a', 'orb', 'stl', 'blk', 'tov', 'pf', 'fg3_pct', 'mp_per_g']
filtered_data[cols_to_zero] = filtered_data[cols_to_zero].fillna(0)

# Extract player_id from player_html so it matches NBA datasets
# Example: 'https://www.basketball-reference.com/players/e/ewingpa01.html' -> 'ewingpa01'
filtered_data["player_id"] = filtered_data["player_html"].str.extract(r'/players/\w/(\w+)\.html')

# load NBA averages dataset
averages = pd.read_csv('Player_Per_Game.csv')
# load NBA advanced stats dataset
advanced = pd.read_csv('Advanced.csv')
# load NBA career info dataset
info = pd.read_csv('Player_Career_Info.csv')

# align column names for merging
averages.rename(columns={"player": "name"}, inplace=True)
advanced.rename(columns={"player": "name"}, inplace=True)
info.rename(columns={"player": "name"}, inplace=True)

# safely extract debut year
info["debut_year"] = pd.to_datetime(info["debut"], errors='coerce').dt.year

# only includes nba players drafted between 2000 and 2010
# keep in mind season represents ending year (2001 means 2000-2001 season)
filtered_info = info[
    (info["player_id"].isin(filtered_data["player_id"])) &
    (info["debut_year"] >= 2000)
]

# filter NBA advanced and averages datasets by player_id
filtered_advanced = advanced[advanced["player_id"].isin(filtered_info["player_id"])]
filtered_averages = averages[averages["player_id"].isin(filtered_info["player_id"])]

# Calculate Career success score

# Group advanced stats by player_id
adv_grouped = filtered_advanced.groupby('player_id').agg(
    total_ws=('ws','sum'),
    peak_ws=('ws','max'),
    vorp=('vorp','sum'),
    ts_percent=('ts_percent','mean')
).reset_index()

# Merge player names for clarity
adv_grouped = adv_grouped.merge(filtered_info[['player_id', 'name']], on='player_id', how='left')

# Calculate CareerStatScore
adv_grouped['CareerStatScore'] = (
    0.5 * adv_grouped['total_ws'] + 
    0.2 * adv_grouped['vorp'] + 
    0.15 * adv_grouped['peak_ws'] + 
    0.15 * adv_grouped['ts_percent']
)

# Sort by CareerStatScore descending
adv_grouped = adv_grouped.sort_values('CareerStatScore', ascending=False)

# drop a few null columns
adv_grouped = adv_grouped.dropna()

# load award share dataset
award_share = pd.read_csv('Player_Award_Shares.csv')

# load all star selections
all_star = pd.read_csv('All_Star_Selections.csv')


# Filter only players in our filtered_info (drafted 2000-2010)
award_share = award_share[award_share['player_id'].isin(filtered_info['player_id'])]
all_star = all_star[all_star['player_id'].isin(filtered_info['player_id'])]

# Define weights for some key awards (adjustable)
award_weights = {
    'nba mvp': 8,
    'nba dpoy': 5,
    'nba roy': 3,
    'nba mip': 2,
    'nba smoy': 1.5,
    'nba clutch_poy': 1
}

# Only consider awards in our weights dictionary
award_share['weight'] = award_share['award'].map(award_weights)
award_share = award_share.dropna(subset=['weight'])

# Calculate weighted score per player from award shares
award_grouped = award_share.groupby('player_id').agg(
    AwardScore=('share', lambda x: np.sum(x * award_share.loc[x.index, 'weight']))
).reset_index()


award_grouped = award_grouped.rename(columns={0: 'AwardScore'})

# Count all star selections per player and weight each by 1
all_star_grouped = all_star.groupby('player_id').size().reset_index(name='AllStarCount')

# Combine awards and all star scores
award_grouped = award_grouped.merge(all_star_grouped, on='player_id', how='left')
award_grouped['AllStarCount'] = award_grouped['AllStarCount'].fillna(0)

# Compute final Awards-Based Career Score (adjust weights as desired)
award_grouped['AwardsCareerScore'] = award_grouped['AwardScore'] + 0.5 * award_grouped['AllStarCount']

# Merge player names for clarity
award_grouped = award_grouped.merge(filtered_info[['player_id', 'name']], on='player_id', how='left')

# Sort by AwardsCareerScore descending
award_grouped = award_grouped.sort_values('AwardsCareerScore', ascending=False)

# load season teams dataset for additional awards
season_teams = pd.read_csv('season_teams.csv')

# Filter only players in our filtered_info (drafted 2000-2010)
season_teams = season_teams[season_teams['player_id'].isin(filtered_info['player_id'])]

# Initialize columns for new awards
season_teams['AllNBAScore'] = 0
season_teams['AllRookieScore'] = 0
season_teams['AllDefenseScore'] = 0

# Assign weights for each type
season_teams.loc[season_teams['type'] == 'all_nba', 'AllNBAScore'] = 2
season_teams.loc[season_teams['type'] == 'all_rookie', 'AllRookieScore'] = 1.5
season_teams.loc[season_teams['type'] == 'all_defense', 'AllDefenseScore'] = 1.25

# Aggregate scores per player
team_awards_grouped = season_teams.groupby('player_id').agg(
    AllNBAScore=('AllNBAScore','sum'),
    AllRookieScore=('AllRookieScore','sum'),
    AllDefenseScore=('AllDefenseScore','sum')
).reset_index()

# Merge with previous award_grouped
award_grouped = award_grouped.merge(team_awards_grouped, on='player_id', how='left')

# Fill NaNs with 0 for players with no additional awards
award_grouped[['AllNBAScore', 'AllRookieScore', 'AllDefenseScore']] = award_grouped[
    ['AllNBAScore', 'AllRookieScore', 'AllDefenseScore']
].fillna(0)

# Compute final Awards-Based Career Score including additional awards
# Weight AllNBA, AllRookie, and AllDefense appropriately (adjust as desired)
award_grouped['AwardsCareerScore'] = (
    award_grouped['AwardScore'] +
    0.5 * award_grouped['AllStarCount'] +
    award_grouped['AllNBAScore'] +
    award_grouped['AllRookieScore'] +
    award_grouped['AllDefenseScore']
)

# Sort by AwardsCareerScore descending
award_grouped = award_grouped.sort_values('AwardsCareerScore', ascending=False)

# Display results
print(award_grouped[['name', 'AwardsCareerScore', 'AwardScore', 'AllStarCount', 
                     'AllNBAScore', 'AllRookieScore', 'AllDefenseScore']].head(20))

# Merge stat score and award score into one DataFrame
total_score = adv_grouped[['player_id', 'CareerStatScore']].merge(
    award_grouped[['player_id', 'AwardsCareerScore']], 
    on='player_id', 
    how='outer'
)

# Fill any missing values with 0 (in case a player has stats but no awards or vice versa)
total_score[['CareerStatScore', 'AwardsCareerScore']] = total_score[['CareerStatScore', 'AwardsCareerScore']].fillna(0)

# Compute TotalCareerScore with 0.7 weight for stats, 0.3 weight for awards
total_score['TotalCareerScore'] = (
    0.7 * total_score['CareerStatScore'] + 
    0.3 * total_score['AwardsCareerScore']
)

# Merge player names for clarity
total_score = total_score.merge(filtered_info[['player_id', 'name']], on='player_id', how='left')

# Sort by TotalCareerScore descending
total_score = total_score.sort_values('TotalCareerScore', ascending=False)

# Display top 20 players
print(total_score[['name', 'TotalCareerScore', 'CareerStatScore', 'AwardsCareerScore']])


# 1) Build per-player college feature table: use each player's final college season
college_last = filtered_data.sort_values(['player_id', 'season_start']).groupby('player_id').tail(1).set_index('player_id')

# 2) Choose college features to test
candidate_features = [
    'pts_per_g', 'trb_per_g', 'ast_per_g',
    'mp_per_g', 'fg_pct', 'ft_pct', 'stl',
    'blk', 'fg3'
]

# Keep only players that also appear in total_score
player_scores = total_score[['player_id', 'TotalCareerScore']].set_index('player_id')
df = college_last.loc[college_last.index.isin(player_scores.index), candidate_features].copy()
df = df.join(player_scores, how='inner')

# Drop any rows missing required values
df = df.dropna(subset=candidate_features + ['TotalCareerScore'])
print(f"Number of players used for regression: {len(df)}")

# Minimal z-score analysis
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

analysis_data = college_last.join(total_score.set_index('player_id')['TotalCareerScore'], how='inner')
analysis_data = analysis_data.dropna(subset=candidate_features + ['TotalCareerScore'])
print(f"Players used in z-score analysis: {len(analysis_data)}")

# Standardize (z-scores)
scaler = StandardScaler()
X = pd.DataFrame(scaler.fit_transform(analysis_data[candidate_features]),
                 columns=candidate_features, index=analysis_data.index)

y = analysis_data['TotalCareerScore']

# Fit multivariate regression
model = LinearRegression()
model.fit(X, y)
coefs = model.coef_

# Coefficient table with univariate R^2
coef_df = pd.DataFrame({'feature': candidate_features, 'coef_per_std': coefs})
uni_r2 = []
for f in candidate_features:
    m = LinearRegression().fit(X[[f]], y)
    uni_r2.append(r2_score(y, m.predict(X[[f]])))
coef_df['univariate_r2'] = uni_r2
coef_df = coef_df.sort_values('coef_per_std', ascending=False).reset_index(drop=True)
print(coef_df)

# Plot effect sizes (1 std dev change)
plt.figure(figsize=(9,6))
sns.barplot(x='coef_per_std', y='feature', data=coef_df, color='tab:blue')
plt.xlabel('Effect on Success per 1 std dev increase (z-score)')
plt.title('Z-score standardized effect sizes (multivariate linear model)')
plt.tight_layout()
plt.show()

# Scatter + lowess for top 4 features
top4 = coef_df['feature'].iloc[:4].tolist()
for f in top4:
    plt.figure(figsize=(6,4))
    sns.regplot(x=X[f], y=y, lowess=True, scatter_kws={'s':20, 'alpha':0.6})
    plt.xlabel(f'{f} (z-score)')
    plt.ylabel('Success')
    plt.title(f'{f} vs Success (z-score); coef={coef_df.loc[coef_df.feature==f,"coef_per_std"].values[0]:.3f}')
    plt.tight_layout()
    plt.show()

# Univariate regressions (each feature alone) to get marginal R^2 and slope
uni_results = []
for f in candidate_features:
    X_uni = sm.add_constant(X[[f]])
    model_uni = sm.OLS(y, X_uni).fit()
    slope = model_uni.params[f]
    r2 = model_uni.rsquared
    uni_results.append((f, slope, r2))
uni_df = pd.DataFrame(uni_results, columns=['feature','slope_0to1','r2']).sort_values('r2', ascending=False)
print("\nUnivariate slopes and R^2 (higher R^2 = stronger single-feature predictor):")
print(uni_df)

# Multicollinearity check: VIF on the X matrix
vif_data = pd.DataFrame()
vif_data['feature'] = X.columns
vif_data['VIF'] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
print("\nVariance Inflation Factors (VIF):")
print(vif_data)

# Correlation heatmap of original college features
plt.figure(figsize=(9,7))
sns.heatmap(college_last[candidate_features].corr(), annot=True, fmt=".2f", cmap='coolwarm')
plt.title('Correlation matrix of college features (raw scale)')
plt.tight_layout()
plt.show()

# Save results to CSV
coef_df.to_csv('college_feature_effects.csv', index=False)
uni_df.to_csv('college_feature_univar.csv', index=False)
print("Saved coefficient summaries to college_feature_effects.csv and college_feature_univar.csv")
